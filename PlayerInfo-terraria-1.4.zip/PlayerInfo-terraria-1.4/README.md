# PlayerInfo
A player info modifier/checker for TShock

| Command, Alias(es)| Permission           | Description                                        |
|-------------------|----------------------|----------------------------------------------------|
| checkinfo, cinfo  | playerinfo.checkinfo | Check another player's max and current HP and mana |
| nick, name        | playerinfo.selfname  | Change your nickname                               |
| stats             | playerinfo.hpnmana   | Set another player's max HP and mana               |
